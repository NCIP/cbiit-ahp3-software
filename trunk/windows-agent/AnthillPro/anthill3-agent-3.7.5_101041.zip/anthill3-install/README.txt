Installation documentation can be found at:
http://www.anthillpro.com/html/products/anthillpro/installation.html

Documentation is available from the Web UI of AnthillPro by clicking
the 'help' link in the upper-right corner.

Documentation is also available online at:
http://www.anthillpro.com/html/products/anthillpro/documentation.html

Support information on AnthillPro can be found at:
http://www.anthillpro.com/html/products/anthillpro/support.html