#!/bin/sh

# save current state
PREVIOUS_DIR=`pwd`
PREVIOUS_ANT_HOME=$ANT_HOME
PREVIOUS_CLASSPATH=$CLASSPATH
OUR_ANT_VERSION=1.7.1

# now change the dir to the root of anthill3-install
SHELL_NAME=$0
SHELL_PATH=`dirname ${SHELL_NAME}`

if [ "." = "$SHELL_PATH" ]
then
   SHELL_PATH=`pwd`
fi
cd ${SHELL_PATH}

# set ANT_HOME
ANT_HOME=opt/apache-ant-${OUR_ANT_VERSION}
export ANT_HOME

chmod +x "opt/apache-ant-${OUR_ANT_VERSION}/bin/ant"

# overwrite CLASSPATH for Ant
CLASSPATH=
export CLASSPATH

# run the install
opt/apache-ant-${OUR_ANT_VERSION}/bin/ant -f install.with.groovy.xml install-agent

# restore previous state
cd ${PREVIOUS_DIR}
ANT_HOME=${PREVIOUS_ANT_HOME}
export ANT_HOME
CLASSPATH=${PREVIOUS_CLASSPATH}
export CLASSPATH
